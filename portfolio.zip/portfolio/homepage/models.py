from django.db import models
from datetime import datetime

class AboutMe(models.Model):
    def __str__(self):
        return self.about_me
    about_me = models.TextField()
    created_at = models.DateTimeField(default = datetime.now, blank = True)

    class Meta:
        verbose_name_plural = "About Me"

class Project(models.Model):
    def __str__(self):
        return self.title

    title = models.CharField(max_length=100, unique=True)
    description = models.CharField(max_length=200)
    content = models.TextField(default="None")
    slug = models.SlugField(unique=True)
    image = models.ImageField()
    githubURL = models.CharField(max_length=200, default="https://github.com/yasseriz")
    created_at = models.DateTimeField(default = datetime.now, blank = True)

    class Meta:
        ordering = ['-created_at']

class ProjectImage(models.Model):
    project = models.ForeignKey(Project, on_delete=models.CASCADE)
    projectImages = models.ImageField()
