from django.shortcuts import render
from .models import AboutMe, Project, ProjectImage
from django.template import loader
from django.views import generic


# Create your views here.
def home(request):
    about_me = AboutMe.objects.all().first
    projects = Project.objects.all()
    context = {'about_me': about_me, 'projects':projects}
    return render(request, 'home.html', context)

class projectDetails(generic.DetailView):
    model = Project
    template_name = "details.html"
    def get_context_data(self, **kwargs):
        images = super(projectDetails, self).get_context_data(**kwargs)
        images['projectImages'] = ProjectImage.objects.all()
        return images