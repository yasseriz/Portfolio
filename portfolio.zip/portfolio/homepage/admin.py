from django.contrib import admin
from .models import AboutMe, Project, ProjectImage
# Register your models here.

class ProjectImageInline(admin.TabularInline):
    model = ProjectImage
    extra = 3

class AboutMeAdmin(admin.ModelAdmin):
    fields = ['about_me', 'created_at']
    list_display = ('about_me', 'created_at')
    list_filter = ['created_at']
    search_fields = ['about_me']

class ProjectAdmin(admin.ModelAdmin):
    fields = ['title', 'description','content', 'slug', 'image', 'githubURL', 'created_at']
    list_display = ('title', 'slug', 'created_at')
    list_filter = ['created_at']
    search_fields = ['title']
    prepopulated_fields = {'slug':('title',)}
    inlines = [
        ProjectImageInline,
    ]

admin.site.register(AboutMe, AboutMeAdmin)
admin.site.register(Project, ProjectAdmin)